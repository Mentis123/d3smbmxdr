# Cloud assistant easter egg

Click the ✦ in the top right. OpenAI invokes the installed Codex CLI through the local Python server, using the existing CLI login and account usage. It requires internet. This is a separate conversation, not this Codex desktop chat. History is saved per provider in browser storage; Clear chat removes that provider’s local history. Main conversations, PDFs and media are not attached. Installed model aliases/devices are attached with the popup conversation. CLI/provider retention policies still apply.

Codex uses `exec --sandbox read-only --skip-git-repo-check --ephemeral`, with the prompt on stdin and the last response captured to a temporary file that is removed afterward. It runs in `data/assistant`. The existing Codex account/config supplies authentication; credentials are never returned to the browser. Read-only limits writes; it is not a promise that the CLI cannot read files on this Windows account. Do not paste secrets. Requests time out after five minutes.

Model downloads are a separate backend action. Open the panel’s model catalog, select a model and confirm the download. Only IDs/aliases returned by Foundry’s catalog are accepted. The backend invokes Foundry directly with argv, never a shell. Downloads can take up to two hours. Keep the app running; chat models appear after refreshing the main selector. Other catalog types are not automatically integrated into speech, image or video features.

## Anthropic and xAI configuration handoff

Edit `assistant-providers.json` on disk. OpenAI is configured; Anthropic and xAI are deliberately disabled until their own CLI/adapter is configured and authenticated. The page reports executable availability, not authentication health; an expired login is reported when sending. Config changes are picked up without restarting.

For each provider, set `enabled` to true and `command` to a JSON array: an absolute executable path followed by that CLI’s noninteractive print-mode arguments. The adapter must read the complete prompt from stdin and write only the final answer as plain text to stdout. Use the provider’s own authentication configuration outside this app; do not put secrets in argv or this JSON. A Node CLI can use `node.exe` plus its installed JavaScript entrypoint. Shell scripts (`.cmd`, `.bat`, `.ps1`) are rejected. This file is trusted local configuration and must not be supplied by a web page or model response.

Claude should configure its own current CLI flags, read-only/no-write permission settings and login. xAI should configure a trusted adapter for its current API/CLI and document its account/key setup. No particular xAI CLI or third-party package is assumed to be official. These adapter slots are implemented but not end-to-end tested until configured.

The bridge shares the existing loopback-only server and Host/Origin checks on port 8765. It is not a general terminal or an MCP server and should not be exposed to the network.
